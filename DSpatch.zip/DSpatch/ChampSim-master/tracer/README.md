This directory contains example tracing utilities that create ChampSim traces. It currently contains:

 - A tracer for use with Intel PIN
 - A conversion program for CVP traces

